---
name: say
description: Speak a short spoken notification to Jonathan aloud through the Mac speakers with `say -v "Aman"`. Use to ping him when he may be away from the screen — a gated-go, a long job finishing, or when he explicitly asks — NEVER routine chatter. Pair with a Sublime note so a missed audio ping still leaves something on screen.
---

# say — spoken ping to Jonathan

## The command
```
say -v "Aman" "<short, natural spoken message>"
```
- Voice is **"Aman"** (English (India), `en_IN`) — quote it. NOT Daniel. The system default voice also works if Aman is ever unavailable.
- Keep the message SHORT and natural — it is read aloud.
- Runs fine from the agent's normal (sandboxed) Bash context. It has worked before, including from the kicker root-conductor seat. No special flags needed.

## Reliability — what actually goes wrong (learned 2026-07-24, the hard way)
Exit 0 is **not** proof it was *heard*. Pings get missed for mundane reasons, not technical blocks:
- **Low system output volume** — seen at 19% (not muted). Quiet enough to miss.
- **Timing** — a one-shot line plays when he isn't listening.

I burned a long debugging loop wrongly blaming the Bash sandbox for "silent" `say`. It was never the sandbox —
an earlier sandboxed `say` was heard fine. The real culprits were volume + timing. Do not re-derive the sandbox
theory.

So for anything that matters: **pair the `say` with a Sublime note** — `subl <file>` — so a missed sound still
leaves a visual he'll see. That is the standing pattern; the audio is the alert, the note is the durable half.

## Verify
Confirm he heard it, or lean on the paired visual. Never assume exit 0 == delivered.

## When to use
Gated-go pings, a long job finishing while he's away, or when he explicitly asks. Never routine.
See memory [[say-to-reach-jonathan]].
