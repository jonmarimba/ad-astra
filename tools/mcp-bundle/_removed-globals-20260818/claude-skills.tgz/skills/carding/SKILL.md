---
name: carding
description: How to write kicker task cards using the established shell-script deck templates. Use whenever you are about to create, refresh, or plan task cards for a kicker package — including any time you catch yourself about to hand-roll `kicker add-task` calls or write requirements into a markdown file instead. Trigger words - card, cards, carding, card this, write the cards, plan a round, deck.
---

# Carding — the established procedure

**You keep reinventing this. Do not.** There is one way to make cards and it is a shell-script deck.
Jonathan asked for it explicitly because he was concerned the work would be done inconsistently:
cards written any other way lose the acceptance criteria, the RED-first requirement, and the
cross-brand review pairing.

## Where it lives

```
/Users/jonathan/svnCheckouts/js-llmKicker/tmp/build-cards-final/
    lib.zsh                       shared library — do not duplicate it
    0700-conduct-invocation-contract.zsh
    …
    1300-human-side-channel.zsh   good reference card, read it before writing a new one
    1400-composed-bakeoff-gate.zsh
```

Rounds are numbered `NNNN-slug.zsh` in execution order. Continue the sequence; do not renumber
existing rounds.

## The contract

`lib.zsh` is **dry-run by default**. Nothing is written until `--apply`.

- `<script> --doc <path.kicker>` → prints `WOULD ADD:` / `SKIP (exists):` and writes nothing
- `<script> --doc <path.kicker> --apply` → creates the cards
- `--refresh` additionally rewrites **open** cards in place; it refuses to touch finished ones

`deck_add_card title body assignee priority` derives the slug from the title, fails closed on an
empty slug/assignee/priority, and **dies if kicker mints a slug different from the derived one** —
so if it errors on a slug mismatch, fix the title, do not fight the tool.

Underneath it calls, positionally (this is why `--priority`-style flags fail):

```
kicker add-task "$DOC" "$title" --json
kicker update task "$slug" nextAction "$body" "priority=P2" "assignee=codex" --doc "$DOC" --json
```

## Skeleton of a round script

```zsh
#!/bin/zsh
set -eu
set -o pipefail
SCRIPT_DIR="${0:A:h}"
ROUND_SCRIPT="${0:t}"
source "$SCRIPT_DIR/lib.zsh"
deck_parse_args "$@"
deck_verify_target
deck_load_slugs

R=1500
SLICE="one sentence naming the slice"
IMPL_BRAND="codex"        # implementer
REVIEW_BRAND="claude"     # reviewer — ALWAYS a different brand than the implementer
NEXT_STEP="run tmp/build-cards-final/<next>.zsh --doc $EXPECTED_DOC (dry-run), read it, then --apply"
ROUND_NOTE="anything deferred by consensus, and to whom it is carried forward"

EXEC_TITLE="1510 execute: <imperative>"
EXEC_BODY="SCOPE: …
RED-FIRST: … (the test that must fail before the work exists, and the mutation that proves it can fail)
ACCEPTANCE: … (binary, by effect)
PROVENANCE: … (which doc/decision/measurement this comes from)"

REVIEW_SWEEP="the exact files and suites the reviewer must sweep"
PROVE_BODY="what the independent prover must demonstrate BY EFFECT, in a hermitage"

deck_emit_round
```

## Rules for the bodies — these are what make a card worth writing

- **ACCEPTANCE must be binary and by effect.** "X is fast" is not a criterion; "the guard goes RED
  when the regression is restored" is. If a criterion cannot fail, it is not a criterion.
- **RED-FIRST is mandatory** — name the failing test and how its teeth are proven (mutation:
  break the fix, watch the named signature go red, restore byte-identical).
- **Quote the human verbatim** where a requirement came from him. His phrasing is the requirement;
  a paraphrase drifts.
- **Cross-brand**: the reviewer brand is never the implementer brand.
- **Carry measurements, not adjectives.** Put the numbers in the body — they are the only part that
  survives being read by someone who wasn't there.
- Cards are born **draft**; `promote-task` makes them actionable.

## Procedure

1. Read `1300-human-side-channel.zsh` for shape.
2. `deck_load_slugs` will tell you what already exists — **check before adding**; a near-duplicate
   card is worse than none.
3. Write the round script. Dry-run it. **Read the dry-run output.**
4. Re-run with `--apply`.
5. For a substantial program, run a planning round with a **Sol** (codex planner) and a **Fable**
   before applying — Jonathan asked for this specifically, so the deck is reviewed cross-brand
   before it becomes cards.

## Why this exists

Rules in memories and system prompts decay within a few turns (measured: a system prompt telling a
node to answer in bullets stopped being obeyed within **three rounds**). Procedures therefore have to
arrive **at the moment of the work**, not be remembered from session start. That is what cards are
for — and this skill is the same mechanism applied to the act of carding itself.
